from django.db import models

# Create your models here.
class data(models.Model):
    document= models.FileField(upload_to='documents/')
    name = models.CharField(max_length=100)
    date = models.DateField()


class Favorites(models.Model):
    document = models.ForeignKey(data, on_delete=models.SET_NULL,null=True)
    user = models.CharField(max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

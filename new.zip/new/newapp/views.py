from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from .models import data
from django.core.paginator import Paginator , EmptyPage  , PageNotAnInteger

def home(request):
    return render(request,'home.html')

def upload(request):
    var = data.objects.all()  # Retrieve all data objects

    page_num = request.GET.get('page', 1)
    p = Paginator(var, 5)

    try:
        page_obj = p.page(page_num)
    except PageNotAnInteger:
        page_obj = p.page(1)
    except EmptyPage:
        page_obj = p.page(1)

    if request.user.is_superuser:
        if request.method == 'POST':
            document = request.FILES.get('document')
            name = request.POST['name']
            date = request.POST['date']
            
            if not name or not date:
                return redirect('upload')
            
            data.objects.create(document=document, name=name, date=date)
            return redirect('upload')
        else:
            context = {
                'var': var,
                'page_obj': page_obj,
            }
            return render(request, 'upload.html', context)
    else:
        context = {
            'var': var,
            'page_obj': page_obj,
        }
        return render(request, 'upload.html', context)
    
def delete(request):
    id = request.GET.get('id')
    var = data.objects.get(id=id)
    var.delete()
    redirect('upload')

def edit(request):
    id = request.GET.get('id')
    var = data.objects.get(id=id)
    return render(request,'update.html',{'var':var})

def update(request):
    if request.method == 'POST':
        id = request.POST['id']
        document = request.FILES.get('document')
        name = request.POST['name']
        date = request.POST['date']
        if document and name and date == '':
            redirect('update')
        else:
            sum = data.objects.get(id=id)
            sum.name = name
            sum.date = date
            sum.document = document
            sum.save()
            redirect('upload')
    else:
        redirect('upload')


def admin_home(request):
    if request.user.is_superuser:
        return render(request,'upload.html')
    else:
        return redirect('')

def user_home(request):
    if request.user.is_superuser:
        return redirect('')
    else:
        var = data.objects.all()
        page_num = request.GET.get('page', 1)
        p = Paginator(var, 5)

        try:
            page_obj = p.page(page_num)
        except PageNotAnInteger:
            page_obj = p.page(1)
        except EmptyPage:
            page_obj = p.page(1)
        context = {
            'var': var,
            'page_obj': page_obj,
        }
        return render(request, 'user_home.html', context)

def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.is_superuser:
                login(request, user)
                return redirect('admin_home')  
    return render(request, 'admin_login.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.is_superuser:
                return redirect('login')
            else:
                login(request, user)
                return redirect('user_home')  
    return render(request, 'login.html')

def user_logout(request):
    logout(request)
    return redirect('login') 
